%filtering test
               %%%% new filtering %%%%
               % % svfile = readtable('GRV_JUGR_2018196_2010MMMMC001V01.csv');
               % % ind2=svfile.Var28==25&svfile.Var30==2;
               % % newtable2=svfile(ind2,:);
               % % ind1=svfile.Var28==25&(svfile.Var29==2|svfile.Var29==3);
               % % newtable1=svfile(ind1,:);




function formattedString = generateStringLine(Ai, Bi)
    % Ensure Ai and Bi are row vectors
    Ai = Ai(:).';
    Bi = Bi(:).';
    
    % Initialize the string
    formattedStringV = '';
    formattedString = '';
    
    % Iterate through each element in Ai
    for i = 1:length(Ai)
        if i > 1
            formattedStringV = [formattedStringV, ' & ']; %#ok<AGROW>
        end
        formattedStringV = [formattedStringV, 'csvfile.Var', num2str(Ai(i)), ' == ']; %#ok<AGROW>
        
        % Add Bi elements to the current part of the string
        for j = 1:length(Bi)
            if j > 1
                formattedString = [formattedString, ' | ',formattedStringV,num2str(Bi(j))]; %#ok<AGROW>
            else
            formattedString = [formattedStringV, num2str(Bi(j))]; %#ok<AGROW>
            end
        end
        formattedString = [formattedString];%;,')']; %#ok<AGROW>
    end
    
    % Display the final string
    disp(['Generated String: ', formattedString]);
end

% Example usage
%Ai = [1, 2];
%Bi = [10, 20, 30];
%generateStringLine(Ai, Bi);

% % % A=[1:3]; B1=[1];B2=[2 3];B3=[1 4 6];
% % % for iA=1:length(A)
% % %     if length(iA)==1
% % %         line=['Var',num2str(iA)];
% % %         for 1:length(B1)
% % %             line_opt=['Var',num2str()]
% % %         end
% % %     end
% % % end
% % % 
% % % line